Practica01
---------------------
Erick Enrique Castro Espinosa
313355381
