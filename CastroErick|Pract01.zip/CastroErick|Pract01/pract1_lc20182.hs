{- |
Module      :  Practica1
Maintainer  :  alorozco.patriot53@gmail.com
Stability   :  experimental
Portability :  portable
Version     :  0.1
-}

module Practica1 where


-- Cálculo de proposiciones
data Prop = VarP String            -- Variable proposicional
          | TTrue                  -- T
          | FFalse                 -- ⊥
          | Neg Prop               -- ¬ Φ
          | Conj Prop Prop         -- Φ ^ Ψ
          | Disy Prop Prop         -- Φ v Ψ
          | Imp Prop Prop          -- Φ -> Ψ
          | Equiv Prop Prop        -- Φ <-> Ψ

-- Imprime una fórmula utilizando operadores infijos
instance Show Prop where
  show (TTrue) = "T"
  show (FFalse)="⊥" 
  show (VarP x)= show x
  show (Neg p) = "¬" ++ "(" ++ show p ++ ")"
  show (Conj p1 p2) = "(" ++ show p1 ++ "^" ++show p2 ++ ")"
  show (Disy p1 p2) = "(" ++ show p1 ++ "v" ++show p2 ++ ")"
  show (Imp p1 p2) = "(" ++ show p1 ++ "=" ++show p2 ++ ")"
  show (Equiv p1 p2) = "(" ++ show p1 ++ "<->" ++show p2 ++ ")"

-- Tipo de dato de sustituciones
type Sub = String -> Prop

-- Sustituciones
substitute :: Prop -> Sub -> Prop
substitute TTrue _ = TTrue
substitute FFalse _ = FFalse
substitute (VarP p) s = s p
substitute (Neg p) s = substitute p s
substitute (Conj p q) s = Conj (substitute p s) (substitute q s)
substitute (Disy p q) s = Disy (substitute p s)(substitute q s)
substitute (Imp p q) s = Imp (substitute p s) (substitute q s)
substitute (Equiv p q) s = Equiv (substitute p s) (substitute q s)



-- Tipo de dato de estado para variables proposicionales
-- Interpretamos como verdaderas, únicamente y exclusivamentelas variables contenidas
-- en la lista dada como estado
type State = [String]

-- Interpretaciones
interp :: Prop -> State -> Bool
interp TTrue _  = True
interp FFalse _ = False
interp (VarP p) s = elem p s
interp (Neg p) s = not (interp p s)
interp (Conj p q) s = (interp p s) && (interp q s)
interp (Disy p q) s = (interp p s) || (interp q s)
interp (Imp p q) s = (not (interp p s)) || (interp q s)
interp (Equiv p q) s = (interp (Imp p q) s) && (interp (Imp q p) s)


-- Dado un estado, ¿será un modelo para una fórmula?
model :: Prop -> State -> Bool
model p s = interp p s

-- Devuelve todas las variables contenidas en una fórmula dada
vars :: Prop -> [String]
vars (VarP x) = [x]
vars (Neg p) = vars p
vars (Conj p1 p2) = union (vars p1) (vars p2)
vars (Disy p1 p2) = union (vars p1) (vars p2)
vars (Imp p1 p2) = union (vars p1) (vars p2)
vars (Equiv p1 p2) = union (vars p1) (vars p2)
vars _ = []

-- union. Función auxiliar que devuelve la union de listas y elimina repetidos.
union :: Eq a => [a] -> [a] -> [a]
union [] l = l
union (x:xs) l
  | elem x l = union xs l
  | otherwise = x:union xs l

  
-- Genera la lista (conjunto) potencia de una lista
powerSet :: Eq a => [a] -> [[a]]
powerSet [] = [[]]
powerSet (x:xs) = xs' ++ map (x:) xs' where xs' = powerSet xs

-- ** Conjunto de Funciones auxiliares **  --

-- Posibles Estados 
estados :: Prop -> [State]
estados p = powerSet $ vars p

-- Posibles Modelos
modelos :: Prop -> [State]
modelos p = [e | e <-estados p, interp p e]

-- | equivL. Función que determina si dos listas son equivalentes.
equivL :: Eq a => [a] -> [a] -> Bool
equivL l1 l2 = e_aux l1 l2 && e_aux l2 l1

-- e_aux. Función que dadas dos listas determina si todos los
-- elementos de la primera están en la segunda.
e_aux :: Eq a => [a] -> [a] -> Bool
e_aux [] l2 = True
e_aux (x:xs) l2 = x `elem` l2 && e_aux xs l2

-- ¿Es tautología?
tautology :: Prop -> Bool
tautology p = equivL (estados p) (modelos p)

-- Equivalencia de fórmulas
equivProp :: Prop -> Prop -> Bool
equivProp p1 p2 = tautology (Equiv p1 p2)

-- Consecuencia lógica
logicConsequence :: [Prop] -> Prop -> Bool
logicConsequence p c = tautology (Imp (premisas p) c)

premisas :: [Prop] -> Prop
premisas [x] = x
premisas (x:xs) = Conj x (premisas xs)
